<?php
/*
Plugin Name: Ecommander WooCommerce Connector
Description: Connect your WooCommerce store to Ecommander.
Version: 1.1
Author: Ecommander
*/

if (!defined('ABSPATH')) exit;

// Add menu to WooCommerce admin
add_action('admin_menu', function () {
  add_menu_page(
    'Ecommander',
    'Ecommander',
    'manage_woocommerce',
    'ecommander-settings',
    'ecommander_render_settings_page',
    'dashicons-admin-links',
    56
  );
});

// Render the settings page
function ecommander_render_settings_page() {
  if (!current_user_can('manage_woocommerce')) {
    wp_die(__('You do not have permission to access this page.'));
  }

  echo '<div class="wrap">';
  echo '<h1>Connect to Ecommander</h1>';

  if (isset($_POST['ecommander_connect']) && check_admin_referer('ecommander_connect_action')) {
    global $wpdb;
    $user = wp_get_current_user();

    $consumer_key = 'ck_' . wc_rand_hash();
    $consumer_secret = 'cs_' . wc_rand_hash();

    $wpdb->insert(
      $wpdb->prefix . 'woocommerce_api_keys',
      [
        'user_id'       => $user->ID,
        'description'   => 'Ecommander Integration',
        'permissions'   => 'read_write',
        'consumer_key'  => wc_api_hash($consumer_key),
        'consumer_secret' => $consumer_secret,
        'truncated_key' => substr($consumer_key, -7),
        'last_access'   => null
      ],
      [ '%d', '%s', '%s', '%s', '%s', '%s', '%s' ]
    );

    $key_id = $wpdb->insert_id;

    if (!$key_id) {
      echo '<div class="notice notice-error"><p>Failed to generate API key. Please try again.</p></div>';
    } else {
      $site_url = get_site_url();
      $redirect = 'https://app.ecommander.io/woocommerce/receive';

      $query = add_query_arg([
        'store'  => $site_url,
        'key'    => $consumer_key,
        'secret' => $consumer_secret,
      ], $redirect);

      echo '<p><strong>Redirecting to Ecommander...</strong></p>';
      echo "<script>window.location.href=" . json_encode($query) . ";</script>";
    }

    echo '</div>';
    return;
  }

  echo '<form method="POST">';
  wp_nonce_field('ecommander_connect_action');
  echo '<p>Click below to connect this store to your Ecommander account.</p>';
  echo '<p><input type="submit" class="button button-primary" name="ecommander_connect" value="Connect to Ecommander"></p>';
  echo '</form>';
  echo '</div>';
}
