<?php
/**
 * Plugin Name: Ecommander Connector
 * Description: Connects your WooCommerce store to the Ecommander platform by generating API keys automatically.
 * Version: 1.0.0
 * Author: Ecommander
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Hook into plugin activation
register_activation_hook(__FILE__, 'ecommander_generate_api_keys');

function ecommander_generate_api_keys() {
    if (!function_exists('wc')) return;

    $user = get_user_by('login', 'admin');
    if (!$user) return;

    $description = 'Ecommander Auto Key';
    $permissions = 'read_write';

    $keys = wc()->api->get_keys()->create($user->ID, $description, $permissions);

    if (!isset($keys['consumer_key']) || !isset($keys['consumer_secret'])) return;

    // Send to your backend
    $response = wp_remote_post('https://app.ecommander.io/api/connect', [
        'method' => 'POST',
        'headers' => [ 'Content-Type' => 'application/json' ],
        'body'    => json_encode([
            'store_url' => get_site_url(),
            'consumer_key' => $keys['consumer_key'],
            'consumer_secret' => $keys['consumer_secret'],
            'admin_email' => get_option('admin_email')
        ])
    ]);
}

// Add admin notice
add_action('admin_notices', function() {
    echo '<div class="notice notice-success is-dismissible">
        <p>Ecommander plugin activated. API credentials sent to Ecommander platform.</p>
    </div>';
});
