<?php
/*
Plugin Name: Ecommander WooCommerce Connector
Description: Automatically sends API credentials to Ecommander after install
Version: 1.0
Author: Ecommander
*/

function ecommander_send_credentials() {
  if (!is_admin()) return;

  $user_id = isset($_GET['user_id']) ? sanitize_text_field($_GET['user_id']) : null;
  if (!$user_id) return;

  $user = get_user_by('login', 'admin');
  if (!$user) return;

  $consumer_key = 'ck_' . wp_generate_password(20, false);
  $consumer_secret = 'cs_' . wp_generate_password(40, false);

  $key_data = WC()->api_keys->generate_key($user->ID, 'Ecommander Integration', 'read_write', $consumer_key, $consumer_secret);

  $site_url = get_site_url();

  wp_remote_post('https://woocomdescbackend-451f66b3eb02.herokuapp.com/woocommerce/connect', [
    'method' => 'POST',
    'headers' => ['Content-Type' => 'application/json'],
    'body' => json_encode([
      'storeUrl' => $site_url,
      'apiId' => $key_data['consumer_key'],
      'secretKey' => $key_data['consumer_secret'],
      'userId' => $user_id
    ]),
    'timeout' => 20
  ]);
}
add_action('admin_init', 'ecommander_send_credentials');
